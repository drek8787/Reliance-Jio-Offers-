<?php
// All you need to do is change your payment details in one place
$upi = 'demo@ybl'; // for change your upi id
$receivername = 'Reliance Jio'; // for change receiver name
